import '../../../duties/data/repositories/duty_repository.dart';
import '../../../master_data/data/repositories/master_data_repository.dart';
import '../../../personnel/data/repositories/personnel_repository.dart';
import '../models/report_filter.dart';
import '../models/report_result.dart';
import '../models/report_summary.dart';

class ReportsService {
  ReportsService({
    DutyRepository? dutyRepository,
    PersonnelRepository? personnelRepository,
    MasterDataRepository? masterDataRepository,
  }) : _dutyRepository = dutyRepository ?? DutyRepository(),
       _personnelRepository = personnelRepository ?? PersonnelRepository(),
       _masterDataRepository = masterDataRepository ?? MasterDataRepository();

  final DutyRepository _dutyRepository;
  final PersonnelRepository _personnelRepository;
  final MasterDataRepository _masterDataRepository;

  Future<ReportResult> generateReport(ReportFilter filter) async {
    throw UnimplementedError();
  }
}
