import 'report_filter.dart';
import 'report_summary.dart';

class ReportResult {
  const ReportResult({
    required this.filter,
    required this.summary,

    required this.duties,
    required this.personnel,
    required this.leaves,
    required this.trainingPrograms,

    required this.generatedAt,
    required this.generatedBy,
  });

  /// الفلاتر المستخدمة
  final ReportFilter filter;

  /// الملخص التنفيذي
  final ReportSummary summary;

  /// بيانات المناوبات
  final List<dynamic> duties;

  /// بيانات القوة البشرية
  final List<dynamic> personnel;

  /// الإجازات
  final List<dynamic> leaves;

  /// البرامج الثقافية
  final List<dynamic> trainingPrograms;

  /// تاريخ إنشاء التقرير
  final DateTime generatedAt;

  /// اسم معد التقرير
  final String generatedBy;
}
