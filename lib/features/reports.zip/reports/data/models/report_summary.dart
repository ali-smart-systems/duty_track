class ReportSummary {
  const ReportSummary({
    required this.totalPersonnel,
    required this.presentPersonnel,
    required this.absentPersonnel,
    required this.leavePersonnel,
    required this.assignedPersonnel,

    required this.totalDuties,
    required this.totalMissionTypes,

    required this.totalLocations,
    required this.totalPosts,

    required this.totalLeaves,

    required this.totalTrainingPrograms,

    required this.totalWorkingHours,

    required this.readinessPercentage,
  });

  /// القوة الأساسية
  final int totalPersonnel;

  /// الموجودون
  final int presentPersonnel;

  /// الغياب
  final int absentPersonnel;

  /// الإجازات
  final int leavePersonnel;

  /// المكلفون
  final int assignedPersonnel;

  /// عدد المناوبات
  final int totalDuties;

  /// عدد المهام
  final int totalMissionTypes;

  /// المواقع
  final int totalLocations;

  /// النقاط
  final int totalPosts;

  /// الإجازات المسجلة
  final int totalLeaves;

  /// البرامج الثقافية
  final int totalTrainingPrograms;

  /// ساعات العمل
  final double totalWorkingHours;

  /// نسبة الجاهزية
  final double readinessPercentage;
}
