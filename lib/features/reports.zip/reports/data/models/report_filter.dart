class ReportFilter {
  const ReportFilter({
    required this.fromDate,
    required this.toDate,
    this.locationId,
    this.postId,
    this.shiftId,
    this.taskTypeId,
    this.status,
    this.departmentId,
    this.rankId,
    this.personnelId,
  });

  /// بداية الفترة
  final DateTime fromDate;

  /// نهاية الفترة
  final DateTime toDate;

  /// الموقع
  final String? locationId;

  /// النقطة
  final String? postId;

  /// الوردية
  final String? shiftId;

  /// نوع المهمة
  final String? taskTypeId;

  /// الحالة
  final String? status;

  /// القسم
  final String? departmentId;

  /// الرتبة
  final String? rankId;

  /// الفرد
  final String? personnelId;

  ReportFilter copyWith({
    DateTime? fromDate,
    DateTime? toDate,
    String? locationId,
    String? postId,
    String? shiftId,
    String? taskTypeId,
    String? status,
    String? departmentId,
    String? rankId,
    String? personnelId,
  }) {
    return ReportFilter(
      fromDate: fromDate ?? this.fromDate,
      toDate: toDate ?? this.toDate,
      locationId: locationId ?? this.locationId,
      postId: postId ?? this.postId,
      shiftId: shiftId ?? this.shiftId,
      taskTypeId: taskTypeId ?? this.taskTypeId,
      status: status ?? this.status,
      departmentId: departmentId ?? this.departmentId,
      rankId: rankId ?? this.rankId,
      personnelId: personnelId ?? this.personnelId,
    );
  }
}
