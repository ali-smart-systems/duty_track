import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../providers/master_data_provider.dart';
import 'add_service_location_screen.dart';

class ServiceLocationsScreen extends ConsumerWidget {
  const ServiceLocationsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final locationsAsync = ref.watch(serviceLocationsProvider);

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('مواقع الخدمة')),
        floatingActionButton: FloatingActionButton.extended(
          icon: const Icon(Icons.cloud_upload),
          label: const Text('تهيئة'),
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => const AddServiceLocationScreen(),
              ),
            );
          },
        ),
        body: locationsAsync.when(
          loading: () => const Center(child: CircularProgressIndicator()),

          error: (error, stackTrace) => Center(
            child: Text('حدث خطأ\n$error', textAlign: TextAlign.center),
          ),

          data: (locations) {
            if (locations.isEmpty) {
              return const Center(
                child: Text(
                  'لا توجد مواقع خدمة',
                  style: TextStyle(fontSize: 18),
                ),
              );
            }

            return ListView.separated(
              padding: const EdgeInsets.all(16),
              itemCount: locations.length,
              separatorBuilder: (context, index) => const SizedBox(height: 8),
              itemBuilder: (context, index) {
                final location = locations[index];

                return Card(
                  elevation: 2,
                  child: ListTile(
                    leading: CircleAvatar(
                      child: Text('${location.displayOrder}'),
                    ),
                    title: Text(location.name),
                    subtitle: Text(location.isActive ? 'نشط' : 'غير نشط'),
                    trailing: PopupMenuButton<String>(
                      onSelected: (value) {
                        switch (value) {
                          case 'edit':
                            break;

                          case 'delete':
                            break;
                        }
                      },
                      itemBuilder: (context) => const [
                        PopupMenuItem(value: 'edit', child: Text('تعديل')),
                        PopupMenuItem(value: 'delete', child: Text('حذف')),
                      ],
                    ),
                  ),
                );
              },
            );
          },
        ),
      ),
    );
  }
}
