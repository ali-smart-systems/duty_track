import 'package:cloud_firestore/cloud_firestore.dart';

class ServicePostModel {
  const ServicePostModel({
    required this.id,
    required this.locationId,
    required this.name,
    required this.displayOrder,
    required this.requiredPersonnel,
    required this.isActive,
    required this.createdAt,
    required this.updatedAt,
  });

  final String id;
  final String locationId;
  final String name;
  final int displayOrder;
  final int requiredPersonnel;
  final bool isActive;
  final DateTime createdAt;
  final DateTime updatedAt;

  ServicePostModel copyWith({
    String? id,
    String? locationId,
    String? name,
    int? displayOrder,
    int? requiredPersonnel,
    bool? isActive,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return ServicePostModel(
      id: id ?? this.id,
      locationId: locationId ?? this.locationId,
      name: name ?? this.name,
      displayOrder: displayOrder ?? this.displayOrder,
      requiredPersonnel: requiredPersonnel ?? this.requiredPersonnel,
      isActive: isActive ?? this.isActive,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }

  factory ServicePostModel.fromMap(Map<String, dynamic> map) {
    return ServicePostModel(
      id: map['id'] as String? ?? '',
      locationId: map['locationId'] as String? ?? '',
      name: map['name'] as String? ?? '',
      displayOrder: map['displayOrder'] as int? ?? 0,
      requiredPersonnel: map['requiredPersonnel'] as int? ?? 1,
      isActive: map['isActive'] as bool? ?? true,
      createdAt: _dateTimeFromValue(map['createdAt']) ?? DateTime.now(),
      updatedAt: _dateTimeFromValue(map['updatedAt']) ?? DateTime.now(),
    );
  }

  factory ServicePostModel.fromFirestore(
    DocumentSnapshot<Map<String, dynamic>> snapshot,
  ) {
    final data = snapshot.data() ?? <String, dynamic>{};

    return ServicePostModel.fromMap({...data, 'id': snapshot.id});
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'locationId': locationId,
      'name': name,
      'displayOrder': displayOrder,
      'requiredPersonnel': requiredPersonnel,
      'isActive': isActive,
      'createdAt': Timestamp.fromDate(createdAt),
      'updatedAt': Timestamp.fromDate(updatedAt),
    };
  }

  Map<String, dynamic> toFirestore() {
    final data = toMap();
    data.remove('id');
    return data;
  }

  static DateTime? _dateTimeFromValue(dynamic value) {
    if (value == null) {
      return null;
    }

    if (value is Timestamp) {
      return value.toDate();
    }

    if (value is DateTime) {
      return value;
    }

    return null;
  }
}
